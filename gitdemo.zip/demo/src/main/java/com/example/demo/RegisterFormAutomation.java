package com.example.demo;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
 
public class RegisterFormAutomation {
    public static void main(String[] args) {
        // Set the path to your chromedriver executable
System.setProperty("webdriver.chrome.driver", "C:\\Users\\2222731\\Downloads\\chromedriver-win64 (1)\\chromedriver-win64\\chromedriver.exe");
 
        // Initialize the WebDriver (e.g., using Chrome)
        WebDriver driver = new ChromeDriver();
 
        try {
            // Open the Angular form page
driver.get("http://localhost:4200/Register");  // Adjust the URL to your local server if necessary
 
            // Locate the form fields and enter values
WebElement usernameField = driver.findElement(By.id("username"));
            usernameField.sendKeys("testuser");
 
WebElement firstnameField = driver.findElement(By.id("firstname"));
            firstnameField.sendKeys("Test");
 
WebElement lastnameField = driver.findElement(By.id("lastname"));
            lastnameField.sendKeys("User");
 
WebElement emailField = driver.findElement(By.id("email"));
            emailField.sendKeys("testuser@example.com");
 
WebElement passwordField = driver.findElement(By.id("password"));
            passwordField.sendKeys("password123");
 
WebElement phoneField = driver.findElement(By.id("phone"));
            phoneField.sendKeys("1234567890");
 
            // Locate and click the register button
WebElement registerButton = driver.findElement(By.id("register"));
registerButton.click();
 
            // Optionally, you can add a wait to see the result
            Thread.sleep(2000);
 
            // Print a success message
            System.out.println("Form submitted successfully!");
 
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            // Close the browser
            //driver.quit();
        }
    }






//import org.openqa.selenium.By;
// 
//import org.openqa.selenium.WebDriver;
// 
//import org.openqa.selenium.WebElement;
// 
//import org.openqa.selenium.chrome.ChromeDriver;
// 
//public class RegisterFormAutomation {
// 
//public static void main(String[] args) { // Set the path to your chromedriver executable
// 
//System.setProperty("webdriver.chrome.driver", "C:\\Users\\2222731\\Downloads\\chromedriver-win64 (1)\\chromedriver-win64\\chromedriver.exe");
// 
//// Initialize the WebDriver (e.g., using Chrome) 
//WebDriver driver = new ChromeDriver();
// 
//try {
// 
//// Open the Angular form page 
//	driver.get("http://localhost:4200/Register"); // Adjust the URL to your local server if necessary
// 
//// Locate the form fields and enter values 
//	WebElement usernameField= driver.findElement(By.id("username")); 
//	usernameField.sendKeys("testuser2");
// 
//WebElement firstnameField =driver.findElement(By.id("firstname")); firstnameField.sendKeys("Test2");
// 
//WebElement lastnameField =driver.findElement(By.id("lastname")); lastnameField.sendKeys("User2");
// 
//WebElement emailField= driver.findElement(By.id("email")); emailField.sendKeys("testuser2@example.com");
// 
//WebElement phoneField =driver.findElement(By.id("phone")); phoneField.sendKeys("0987654321");
//
//
//// Locate and click the register button 
//WebElement registerButton = driver.findElement(By.id("register")); registerButton.click();
// 
//// Optionally, you can add a wait to see the result 
//Thread.sleep(2000);
// 
//// Print a success message 
//System.out.println("Form submitted successfully!");
// 
//}catch (InterruptedException e) {
////  e.printStackTrace();
// 
//} finally {
// 
//// Close the browser
// 
////driver.quit();
// 
//}
// 
//}


}