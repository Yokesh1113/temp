import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { UploadDocumentService } from '../upload-document.service';

@Component({
  selector: 'app-upload-documents',
  templateUrl: './upload-documents.component.html',
  styleUrl: './upload-documents.component.css'
})
export class UploadDocumentsComponent {
  userName: string = '';
  file: File | null = null;
  url: string = '';
  fileLink: string = '';
  apiKey: string ='';
  apiProvider: string='';
  message: string = '';
 
  constructor(private uploadDocumentService: UploadDocumentService) { }
 
  onFileChange(event: any) {
    this.file = event.target.files[0];
  }
 
  onSubmit() {
    const formData = new FormData();
    formData.append('userName', this.userName);
    formData.append('apiKey',this.apiKey);
    formData.append('apiProvider',this.apiProvider);
    if (this.file) {
      const maxSize = 5*1024 *1024; //5MB in bytes
      if(this.file.size>maxSize){
        console.error('File size exceeds the maximum limit of 5MB');
        this.message = 'File size exceeds the maximum limit of 5MB';
        return;
      }
      formData.append('file', this.file);
    }
    if (this.url) {
      formData.append('url', this.url);
    }
    if (this.fileLink) {
      formData.append('fileLink', this.fileLink);
    }
 
    this.uploadDocumentService.uploadDocument(formData).subscribe(
      response => {
        console.log(response);
        this.message = 'Document uploaded successfully';
      },
      error => {
      console.error(error);
        this.message = 'Document upload failed';
    }
    );
  }
}
