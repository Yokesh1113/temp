import { Component, OnInit } from '@angular/core';
import { NgModule } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
} from '@angular/common/http';
import { AuthService } from '../auth.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  email: string = '';
  password: string = '';
  name: string = '';

  constructor(
    private http: HttpClient,
    private router: ActivatedRoute,
    private route: Router,
    private authService: AuthService
  ) {}
  ngOnInit(): void {
    this.name = this.router.snapshot.params['name'];
  }
  login() {
    let bodyData = {
      email: this.email,
      password: this.password,
    };
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
    };
    this.http.post("http://localhost:8090/login",bodyData,httpOptions).subscribe((resultData:
    any)=>
    {
     console.log(resultData);
      alert("Successfully Login");

      // this.authService.setAssociateId(resultData.associateId);
      this.email='';
      this.password='';
      this.route.navigate(['/Home']);
    },
    error=>{
      console.error("Error during Login",error);
      alert("Login failed.Please check the details.");
    }
    );
    this.route.navigate(['/Home']);
  }
}
