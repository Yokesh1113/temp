import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { UploadDocumentService } from '../upload-document.service';

@Component({
  selector: 'app-upload-documents',
  templateUrl: './upload-documents.component.html',
  styleUrl: './upload-documents.component.css'
})
export class UploadDocumentsComponent {
  userName: string = '';
  file: File | null = null;
  url: string = '';
  fileLink: string = '';
  apiKey: string ='';
  apiProvider: string='';
  message: string = '';
  documentId: string='';
  documentName: string='';
 
  constructor(private uploadDocumentService: UploadDocumentService) { }
 
  onFileChange(event: any) {
    this.file = event.target.files[0];
  }
 
  onSubmit() {
    const formData = new FormData();
    formData.append('userName', this.userName);
    formData.append('apiKey',this.apiKey);
    formData.append('apiProvider',this.apiProvider);
    if (this.file) {
      formData.append('file', this.file);
    }
    if (this.url) {
      formData.append('url', this.url);
    }
    if (this.fileLink) {
      formData.append('fileLink', this.fileLink);
    }
 
    this.uploadDocumentService.uploadDocument(formData).subscribe(
      response => {
        console.log(response);
        this.message = 'Document uploaded successfully';
      },
      error => {
      console.error(error);
        this.message = 'Document upload failed';
    }
    );
  }
  // download(): void {
  //   if (!this.documentId) {
  //     console.error('No document to download');
  //     return;
  //   }
   
  //   this.uploadDocumentService.downloadDocument(this.documentId).subscribe(
  //     blob => {
  //       // Create URL for blob object
  //       const url = window.URL.createObjectURL(blob);
  //       // Create a link element
  //       const a = document.createElement('a');
  //       // Set the href attribute of the link
  //       a.href = url;
  //       // Set the download attribute to specify filename
  // a.download = this.documentName; // Use dynamic document name
  //       // Append the link to the body
  //       document.body.appendChild(a);
  //       // Programmatically click the link to trigger the download
  // a.click();
  //       // Clean up by revoking the object URL
  //       window.URL.revokeObjectURL(url);
  //       // Remove the link from the body
  //       document.body.removeChild(a);
  //     },
  //     error => {
  //       console.error('Download error:', error);
  //     }
  //   );
  // }
}
  


