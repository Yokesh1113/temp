import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UploadDocumentService {
 
  private baseUrl = 'http://localhost:8090/api'; // Adjust the base URL as needed
 
  constructor(private http: HttpClient) { }
 
  uploadDocument(formData: FormData): Observable<any> {
return this.http.post(`${this.baseUrl}/documents/upload`, formData, {responseType: 'text'});
  }
 
  getDocumentsByUserName(userName: string): Observable<any> {
    return this.http.get(`${this.baseUrl}/documents/user/${userName}`);
  }
  // downloadDocument(documentId:string):
  // Observable<Blob>{
  //   return this.http.get(`${this.baseUrl}/documents/download/${documentId}`,
  //   {responseType:'blob'});
  // }
}

