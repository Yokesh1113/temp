import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {
  userName: string = '';
 
  constructor(private router: Router) { }
 
  navigateToUpload() {
    this.router.navigate(['/upload-documents'], { queryParams: { userName: this.userName } });
  }
}


